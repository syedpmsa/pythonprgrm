#Factorial Program Using for loop

num = int(input("Enter factorial No:"))
result = 1
for i in range(num, 0, -1):
    result = result*i
print("The Factorial Number is :", result)