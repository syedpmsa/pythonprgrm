def perfectsq(a,b):                         # create function perfect sq and take two parameter a,b
    for i in range(a,b+1):                  #using for loop take one by one value from for loop
        if i**(0.5)==int(i**(0.5)):         #check if condtion and to find perfect Squrare
            print("the perfact square is: ",i)   #finally display the result
num1=int(input("enter staring Number:"))        #take input from user
num2=int(input("enter the last Number:"))
perfectsq(num1,num2)                              #function calling

