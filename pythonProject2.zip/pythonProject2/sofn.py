                                                   # Python program to find sum of n numbers

                                                      # total number you want to enter
n = int(input('How many numbers: '))

                                                       # denotes total sum of n numbers
total_sum = 0

for i in range (n):
    # take inputs
    num = int(input('Enter number: '))
    # calculate total sum of numbers
    total_sum += num

# print sum of numbers
print('The sum of numbers = ', total_sum)