#Program to Check Entered Number is Perfect or Not
n = int(input("Enter The Number:"))
result = 0
for i in range(1,n):
    if (n % i)== 0:
        result = result+i
if result == n:
    print(n,"perfect Number")
else:
    print(n,"Not a perfect Number")

