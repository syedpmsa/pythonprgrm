# Python program to check given number is an even or odd
num=int(input("Enter the Number:")) # Take Number from User
if num%2==0: #check if statement
    print("the even Number is:",num)
else:
    print("the odd Number is :",num)